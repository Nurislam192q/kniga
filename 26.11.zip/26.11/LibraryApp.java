import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class LibraryApp extends JFrame {
    private static final Path DATA_FILE = Path.of("library-data.json");
    private static final String ADMIN = "АДМИНИСТРАТОР";
    private static final String LIBRARIAN = "БИБЛИОТЕКАРЬ";

    private final CardLayout cards = new CardLayout();
    private final JPanel root = new JPanel(cards);
    private final List<User> users = new ArrayList<>();
    private final List<Book> books = new ArrayList<>();
    private final List<Loan> loans = new ArrayList<>();
    private String currentUsername;
    private String currentRole;
    private int nextBookId = 1;
    private int nextLoanId = 1;
    private JTable booksTable;
    private JTable loansTable;
    private DefaultTableModel booksModel;
    private DefaultTableModel loansModel;
    private JTextField searchField;
    private JLabel catalogStatus;

    public LibraryApp() throws IOException {
        super("Библиотечная система");
        loadData();
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(900, 600));
        setSize(1100, 700);
        setLocationRelativeTo(null);
        root.add(createLoginPanel(), "login");
        setContentPane(root);
    }

    private void loadData() throws IOException {
        if (!Files.exists(DATA_FILE)) {
            users.add(new User("admin", hashPassword("admin123"), ADMIN));
            users.add(new User("librarian", hashPassword("lib123"), LIBRARIAN));
            addDemoBooks();
            saveData();
            return;
        }

        Object parsed = new JsonParser(Files.readString(DATA_FILE, StandardCharsets.UTF_8)).parse();
        Map<String, Object> data = asObject(parsed);
        for (Object value : asArray(data.get("users"))) {
            Map<String, Object> item = asObject(value);
            users.add(new User(asString(item.get("username")), asString(item.get("passwordHash")),
                    asString(item.get("role"))));
        }
        for (Object value : asArray(data.get("books"))) {
            Map<String, Object> item = asObject(value);
            Book book = new Book(asInt(item.get("id")), asString(item.get("title")),
                    asString(item.get("author")), asInt(item.get("year")),
                    asString(item.get("genre")), asInt(item.get("total")));
            books.add(book);
            nextBookId = Math.max(nextBookId, book.id + 1);
        }
        for (Object value : asArray(data.get("loans"))) {
            Map<String, Object> item = asObject(value);
            Object returnedAt = item.get("returnedAt");
            Loan loan = new Loan(asInt(item.get("id")), asInt(item.get("bookId")),
                    asString(item.get("bookTitle")), asString(item.get("reader")),
                    asString(item.get("issueDate")), returnedAt == null ? null : asString(returnedAt));
            loans.add(loan);
            nextLoanId = Math.max(nextLoanId, loan.id + 1);
        }
    }

    private void addDemoBooks() {
        String[][] samples = {
                {"Мастер и Маргарита", "Михаил Булгаков", "1967", "Роман", "4"},
                {"Преступление и наказание", "Фёдор Достоевский", "1866", "Роман", "3"},
                {"Война и мир", "Лев Толстой", "1869", "Классика", "5"},
                {"Евгений Онегин", "Александр Пушкин", "1833", "Поэзия", "2"},
                {"Собачье сердце", "Михаил Булгаков", "1925", "Сатира", "3"},
                {"Отцы и дети", "Иван Тургенев", "1862", "Роман", "2"},
                {"Идиот", "Фёдор Достоевский", "1869", "Роман", "2"},
                {"Анна Каренина", "Лев Толстой", "1877", "Роман", "3"},
                {"Герой нашего времени", "Михаил Лермонтов", "1840", "Классика", "2"},
                {"Двенадцать стульев", "Илья Ильф, Евгений Петров", "1928", "Сатира", "4"}
        };
        for (String[] sample : samples) {
            books.add(new Book(nextBookId++, sample[0], sample[1],
                    Integer.parseInt(sample[2]), sample[3], Integer.parseInt(sample[4])));
        }
    }

    private void saveData() throws IOException {
        List<Object> userData = new ArrayList<>();
        for (User user : users) {
            userData.add(jsonObject("username", user.username, "passwordHash", user.passwordHash, "role", user.role));
        }
        List<Object> bookData = new ArrayList<>();
        for (Book book : books) {
            bookData.add(jsonObject("id", book.id, "title", book.title, "author", book.author,
                    "year", book.year, "genre", book.genre, "total", book.total));
        }
        List<Object> loanData = new ArrayList<>();
        for (Loan loan : loans) {
            loanData.add(jsonObject("id", loan.id, "bookId", loan.bookId, "bookTitle", loan.bookTitle,
                    "reader", loan.reader, "issueDate", loan.issueDate, "returnedAt", loan.returnedAt));
        }
        String json = JsonWriter.write(jsonObject("users", userData, "books", bookData, "loans", loanData));
        Path temporary = DATA_FILE.resolveSibling(DATA_FILE.getFileName() + ".tmp");
        Files.writeString(temporary, json, StandardCharsets.UTF_8);
        try {
            Files.move(temporary, DATA_FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException exception) {
            Files.move(temporary, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private JPanel createLoginPanel() {
        JPanel page = new JPanel(new GridBagLayout());
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Вход в систему"),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(7, 7, 7, 7);
        c.fill = GridBagConstraints.HORIZONTAL;

        JTextField usernameField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);
        addFormRow(form, c, 0, "Логин:", usernameField);
        addFormRow(form, c, 1, "Пароль:", passwordField);
        JButton loginButton = new JButton("Войти");
        JButton exitButton = new JButton("Выход");
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttons.add(loginButton);
        buttons.add(exitButton);
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 2;
        form.add(buttons, c);
        page.add(form);

        loginButton.addActionListener(event -> {
            String username = usernameField.getText().trim();
            char[] password = passwordField.getPassword();
            try {
                String role = authenticate(username, password);
                if (role == null) {
                    JOptionPane.showMessageDialog(this, "Неверный логин или пароль.",
                            "Ошибка входа", JOptionPane.ERROR_MESSAGE);
                    passwordField.setText("");
                    return;
                }
                currentUsername = username;
                currentRole = role;
                showMainPanel();
            } finally {
                java.util.Arrays.fill(password, '\0');
            }
        });
        passwordField.addActionListener(event -> loginButton.doClick());
        exitButton.addActionListener(event -> dispose());
        return page;
    }

    private String authenticate(String username, char[] password) {
        byte[] actual = hashPassword(new String(password)).getBytes(StandardCharsets.US_ASCII);
        for (User user : users) {
            if (user.username.equals(username)
                    && MessageDigest.isEqual(user.passwordHash.getBytes(StandardCharsets.US_ASCII), actual)) {
                return user.role;
            }
        }
        return null;
    }

    private void showMainPanel() {
        JPanel page = new JPanel(new BorderLayout(8, 8));
        page.setBorder(BorderFactory.createEmptyBorder(10, 12, 12, 12));
        JPanel header = new JPanel(new BorderLayout());
        JLabel title = new JLabel("Библиотечная система");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
        header.add(title, BorderLayout.WEST);
        JPanel account = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        account.add(new JLabel(currentUsername + " — " + currentRole));
        JButton logoutButton = new JButton("Выйти из аккаунта");
        account.add(logoutButton);
        header.add(account, BorderLayout.EAST);
        page.add(header, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Список книг", createCatalogPanel());
        tabs.addTab("Выданные книги", createLoansPanel());
        page.add(tabs, BorderLayout.CENTER);

        logoutButton.addActionListener(event -> {
            currentUsername = null;
            currentRole = null;
            root.remove(page);
            cards.show(root, "login");
            root.revalidate();
            root.repaint();
        });
        root.add(page, "main");
        cards.show(root, "main");
        revalidate();
        repaint();
    }

    private JPanel createCatalogPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        JPanel top = new JPanel(new BorderLayout(8, 8));
        JPanel search = new JPanel(new BorderLayout(8, 0));
        search.add(new JLabel("Поиск по названию, автору или жанру:"), BorderLayout.WEST);
        searchField = new JTextField();
        search.add(searchField, BorderLayout.CENTER);
        top.add(search, BorderLayout.NORTH);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
        if (ADMIN.equals(currentRole)) {
            JButton addButton = new JButton("Добавить книгу");
            JButton editButton = new JButton("Редактировать");
            JButton deleteButton = new JButton("Удалить");
            actions.add(addButton);
            actions.add(editButton);
            actions.add(deleteButton);
            addButton.addActionListener(event -> addBook());
            editButton.addActionListener(event -> editSelectedBook());
            deleteButton.addActionListener(event -> deleteSelectedBook());
        }
        JButton issueButton = new JButton("Выдать книгу");
        actions.add(issueButton);
        issueButton.addActionListener(event -> issueSelectedBook());
        top.add(actions, BorderLayout.SOUTH);
        panel.add(top, BorderLayout.NORTH);

        booksModel = readOnlyModel("№", "Название книги", "Автор", "Год", "Жанр", "Всего", "Доступно");
        booksTable = new JTable(booksModel);
        booksTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        booksTable.setAutoCreateRowSorter(true);
        panel.add(new JScrollPane(booksTable), BorderLayout.CENTER);
        catalogStatus = new JLabel(" ");
        panel.add(catalogStatus, BorderLayout.SOUTH);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            private void changed() { refreshBooks(); }
            public void insertUpdate(DocumentEvent event) { changed(); }
            public void removeUpdate(DocumentEvent event) { changed(); }
            public void changedUpdate(DocumentEvent event) { changed(); }
        });
        refreshBooks();
        return panel;
    }

    private JPanel createLoansPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        loansModel = readOnlyModel("№", "Книга", "Читатель", "Дата выдачи", "Статус", "Дата возврата");
        loansTable = new JTable(loansModel);
        loansTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        loansTable.setAutoCreateRowSorter(true);
        panel.add(new JScrollPane(loansTable), BorderLayout.CENTER);
        JButton returnButton = new JButton("Вернуть выбранную книгу");
        returnButton.addActionListener(event -> returnSelectedBook());
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
        actions.add(returnButton);
        panel.add(actions, BorderLayout.NORTH);
        refreshLoans();
        return panel;
    }

    private static DefaultTableModel readOnlyModel(String... columns) {
        return new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
    }

    private void refreshBooks() {
        if (booksModel == null) return;
        booksModel.setRowCount(0);
        String needle = searchField == null ? "" : searchField.getText().trim().toLowerCase(Locale.ROOT);
        int matches = 0;
        for (Book book : books) {
            String searchable = (book.title + " " + book.author + " " + book.genre).toLowerCase(Locale.ROOT);
            if (!searchable.contains(needle)) continue;
            booksModel.addRow(new Object[]{book.id, book.title, book.author, book.year, book.genre,
                    book.total, availableCopies(book)});
            matches++;
        }
        catalogStatus.setText(matches == 0 ? "Совпадений не найдено." : "Найдено книг: " + matches);
    }

    private void refreshLoans() {
        if (loansModel == null) return;
        loansModel.setRowCount(0);
        for (int i = loans.size() - 1; i >= 0; i--) {
            Loan loan = loans.get(i);
            loansModel.addRow(new Object[]{loan.id, loan.bookTitle, loan.reader, loan.issueDate,
                    loan.returnedAt == null ? "Выдана" : "Возвращена",
                    loan.returnedAt == null ? "" : loan.returnedAt});
        }
    }

    private void addBook() {
        BookInput input = showBookDialog(null);
        if (input == null) return;
        Book book = new Book(nextBookId++, input.title, input.author, input.year, input.genre, input.total);
        books.add(book);
        saveAndRefresh();
    }

    private void editSelectedBook() {
        Integer id = selectedId(booksTable);
        if (id == null) {
            showInfo("Сначала выберите книгу в таблице.");
            return;
        }
        Book book = findBook(id);
        if (book == null) {
            showInfo("Выбранная книга больше не существует.");
            refreshBooks();
            return;
        }
        BookInput input = showBookDialog(new BookInput(book.title, book.author, book.year, book.genre, book.total));
        if (input == null) return;
        int activeLoans = activeLoanCount(book.id);
        if (input.total < activeLoans) {
            showInfo("Количество экземпляров не может быть меньше уже выданных: " + activeLoans + ".");
            return;
        }
        book.title = input.title;
        book.author = input.author;
        book.year = input.year;
        book.genre = input.genre;
        book.total = input.total;
        saveAndRefresh();
    }

    private void deleteSelectedBook() {
        Integer id = selectedId(booksTable);
        if (id == null) {
            showInfo("Сначала выберите книгу в таблице.");
            return;
        }
        if (JOptionPane.showConfirmDialog(this, "Удалить выбранную книгу из каталога?",
                "Подтверждение удаления", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        if (activeLoanCount(id) > 0) {
            showInfo("Нельзя удалить книгу, пока есть невозвращенные экземпляры.");
            return;
        }
        books.removeIf(book -> book.id == id);
        saveAndRefresh();
    }

    private void issueSelectedBook() {
        Integer id = selectedId(booksTable);
        if (id == null) {
            showInfo("Сначала выберите книгу в таблице.");
            return;
        }
        Book book = findBook(id);
        if (book == null) {
            showInfo("Книга больше не существует.");
            refreshBooks();
            return;
        }
        if (availableCopies(book) <= 0) {
            showInfo("Нет доступных экземпляров этой книги.");
            return;
        }
        String reader = JOptionPane.showInputDialog(this, "Введите имя читателя:", "Выдать книгу",
                JOptionPane.PLAIN_MESSAGE);
        if (reader == null) return;
        reader = reader.trim();
        if (reader.isEmpty()) {
            showInfo("Имя читателя обязательно.");
            return;
        }
        loans.add(new Loan(nextLoanId++, book.id, book.title, reader, LocalDate.now().toString(), null));
        saveAndRefresh();
    }

    private void returnSelectedBook() {
        Integer id = selectedId(loansTable);
        if (id == null) {
            showInfo("Сначала выберите выдачу в таблице.");
            return;
        }
        Loan loan = findLoan(id);
        if (loan == null || loan.returnedAt != null) {
            showInfo("Эта книга уже возвращена.");
            return;
        }
        loan.returnedAt = LocalDate.now().toString();
        saveAndRefresh();
    }

    private void saveAndRefresh() {
        try {
            saveData();
            refreshBooks();
            refreshLoans();
        } catch (IOException exception) {
            JOptionPane.showMessageDialog(this, "Не удалось сохранить данные в "
                    + DATA_FILE.toAbsolutePath() + "\n" + exception.getMessage(),
                    "Ошибка сохранения", JOptionPane.ERROR_MESSAGE);
        }
    }

    private BookInput showBookDialog(BookInput existing) {
        JTextField title = new JTextField(existing == null ? "" : existing.title, 24);
        JTextField author = new JTextField(existing == null ? "" : existing.author, 24);
        JTextField year = new JTextField(existing == null ? "" : Integer.toString(existing.year), 24);
        JTextField genre = new JTextField(existing == null ? "" : existing.genre, 24);
        JTextField total = new JTextField(existing == null ? "" : Integer.toString(existing.total), 24);
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new JLabel("Название книги:")); form.add(title);
        form.add(new JLabel("Автор:")); form.add(author);
        form.add(new JLabel("Год издания:")); form.add(year);
        form.add(new JLabel("Жанр:")); form.add(genre);
        form.add(new JLabel("Количество экземпляров:")); form.add(total);
        while (true) {
            int answer = JOptionPane.showConfirmDialog(this, form,
                    existing == null ? "Добавить книгу" : "Редактировать книгу",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (answer != JOptionPane.OK_OPTION) return null;
            String titleValue = title.getText().trim();
            String authorValue = author.getText().trim();
            String genreValue = genre.getText().trim();
            if (titleValue.isEmpty() || authorValue.isEmpty() || genreValue.isEmpty()) {
                showInfo("Заполните название, автора и жанр.");
                continue;
            }
            try {
                int yearValue = Integer.parseInt(year.getText().trim());
                int totalValue = Integer.parseInt(total.getText().trim());
                if (yearValue <= 0 || totalValue < 0) {
                    showInfo("Год должен быть положительным числом, а количество — не меньше нуля.");
                    continue;
                }
                return new BookInput(titleValue, authorValue, yearValue, genreValue, totalValue);
            } catch (NumberFormatException exception) {
                showInfo("Год и количество экземпляров должны быть целыми числами.");
            }
        }
    }

    private Book findBook(int id) {
        for (Book book : books) if (book.id == id) return book;
        return null;
    }

    private Loan findLoan(int id) {
        for (Loan loan : loans) if (loan.id == id) return loan;
        return null;
    }

    private int availableCopies(Book book) {
        return book.total - activeLoanCount(book.id);
    }

    private int activeLoanCount(int bookId) {
        int count = 0;
        for (Loan loan : loans) {
            if (loan.bookId == bookId && loan.returnedAt == null) count++;
        }
        return count;
    }

    private static Integer selectedId(JTable table) {
        if (table == null) return null;
        int selected = table.getSelectedRow();
        if (selected < 0) return null;
        return ((Number) table.getModel().getValueAt(table.convertRowIndexToModel(selected), 0)).intValue();
    }

    private static void addFormRow(JPanel panel, GridBagConstraints c, int row, String label, JComponent field) {
        c.gridwidth = 1;
        c.gridx = 0;
        c.gridy = row;
        panel.add(new JLabel(label), c);
        c.gridx = 1;
        panel.add(field, c);
    }

    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Библиотека", JOptionPane.INFORMATION_MESSAGE);
    }

    private static String hashPassword(String password) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(password.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is not available", exception);
        }
    }

    private static Map<String, Object> jsonObject(Object... pairs) {
        Map<String, Object> object = new LinkedHashMap<>();
        for (int i = 0; i < pairs.length; i += 2) object.put((String) pairs[i], pairs[i + 1]);
        return object;
    }

    private static Map<String, Object> asObject(Object value) throws IOException {
        if (!(value instanceof Map<?, ?> map)) throw new IOException("Некорректный JSON: ожидался объект.");
        Map<String, Object> result = new LinkedHashMap<>();
        for (Map.Entry<?, ?> entry : map.entrySet()) result.put((String) entry.getKey(), entry.getValue());
        return result;
    }

    private static List<Object> asArray(Object value) throws IOException {
        if (!(value instanceof List<?> list)) throw new IOException("Некорректный JSON: ожидался список.");
        return new ArrayList<>(list);
    }

    private static String asString(Object value) throws IOException {
        if (!(value instanceof String text)) throw new IOException("Некорректный JSON: ожидался текст.");
        return text;
    }

    private static int asInt(Object value) throws IOException {
        if (!(value instanceof Number number)) throw new IOException("Некорректный JSON: ожидалось число.");
        return Math.toIntExact(number.longValue());
    }

    private record User(String username, String passwordHash, String role) { }
    private record BookInput(String title, String author, int year, String genre, int total) { }

    private static final class Book {
        private final int id;
        private String title;
        private String author;
        private int year;
        private String genre;
        private int total;

        private Book(int id, String title, String author, int year, String genre, int total) {
            this.id = id;
            this.title = title;
            this.author = author;
            this.year = year;
            this.genre = genre;
            this.total = total;
        }
    }

    private static final class Loan {
        private final int id;
        private final int bookId;
        private final String bookTitle;
        private final String reader;
        private final String issueDate;
        private String returnedAt;

        private Loan(int id, int bookId, String bookTitle, String reader, String issueDate, String returnedAt) {
            this.id = id;
            this.bookId = bookId;
            this.bookTitle = bookTitle;
            this.reader = reader;
            this.issueDate = issueDate;
            this.returnedAt = returnedAt;
        }
    }

    private static final class JsonWriter {
        private static String write(Object value) {
            StringBuilder output = new StringBuilder();
            append(output, value);
            return output.append(System.lineSeparator()).toString();
        }

        private static void append(StringBuilder output, Object value) {
            if (value == null) {
                output.append("null");
            } else if (value instanceof String text) {
                appendString(output, text);
            } else if (value instanceof Number || value instanceof Boolean) {
                output.append(value);
            } else if (value instanceof Map<?, ?> object) {
                output.append('{');
                boolean first = true;
                for (Map.Entry<?, ?> entry : object.entrySet()) {
                    if (!first) output.append(',');
                    first = false;
                    appendString(output, (String) entry.getKey());
                    output.append(':');
                    append(output, entry.getValue());
                }
                output.append('}');
            } else if (value instanceof List<?> array) {
                output.append('[');
                for (int i = 0; i < array.size(); i++) {
                    if (i > 0) output.append(',');
                    append(output, array.get(i));
                }
                output.append(']');
            } else {
                throw new IllegalArgumentException("Unsupported JSON value: " + value.getClass());
            }
        }

        private static void appendString(StringBuilder output, String text) {
            output.append('"');
            for (int i = 0; i < text.length(); i++) {
                char ch = text.charAt(i);
                switch (ch) {
                    case '"' -> output.append("\\\"");
                    case '\\' -> output.append("\\\\");
                    case '\b' -> output.append("\\b");
                    case '\f' -> output.append("\\f");
                    case '\n' -> output.append("\\n");
                    case '\r' -> output.append("\\r");
                    case '\t' -> output.append("\\t");
                    default -> {
                        if (ch < 0x20) output.append(String.format("\\u%04x", (int) ch));
                        else output.append(ch);
                    }
                }
            }
            output.append('"');
        }
    }

    private static final class JsonParser {
        private final String source;
        private int position;

        private JsonParser(String source) { this.source = source; }

        private Object parse() throws IOException {
            Object value = parseValue();
            skipWhitespace();
            if (position != source.length()) fail("Лишние символы в конце JSON.");
            return value;
        }

        private Object parseValue() throws IOException {
            skipWhitespace();
            if (position >= source.length()) return fail("Неожиданный конец JSON.");
            return switch (source.charAt(position)) {
                case '{' -> parseObject();
                case '[' -> parseArray();
                case '"' -> parseString();
                case 't' -> parseLiteral("true", Boolean.TRUE);
                case 'f' -> parseLiteral("false", Boolean.FALSE);
                case 'n' -> parseLiteral("null", null);
                default -> parseNumber();
            };
        }

        private Map<String, Object> parseObject() throws IOException {
            position++;
            Map<String, Object> object = new LinkedHashMap<>();
            skipWhitespace();
            if (take('}')) return object;
            while (true) {
                skipWhitespace();
                if (position >= source.length() || source.charAt(position) != '"') {
                    return fail("Ожидался ключ объекта.");
                }
                String key = parseString();
                skipWhitespace();
                expect(':');
                object.put(key, parseValue());
                skipWhitespace();
                if (take('}')) return object;
                expect(',');
            }
        }

        private List<Object> parseArray() throws IOException {
            position++;
            List<Object> array = new ArrayList<>();
            skipWhitespace();
            if (take(']')) return array;
            while (true) {
                array.add(parseValue());
                skipWhitespace();
                if (take(']')) return array;
                expect(',');
            }
        }

        private String parseString() throws IOException {
            expect('"');
            StringBuilder text = new StringBuilder();
            while (position < source.length()) {
                char ch = source.charAt(position++);
                if (ch == '"') return text.toString();
                if (ch != '\\') {
                    if (ch < 0x20) return fail("Управляющий символ в строке JSON.");
                    text.append(ch);
                    continue;
                }
                if (position >= source.length()) return fail("Незаконченная escape-последовательность.");
                char escaped = source.charAt(position++);
                switch (escaped) {
                    case '"', '\\', '/' -> text.append(escaped);
                    case 'b' -> text.append('\b');
                    case 'f' -> text.append('\f');
                    case 'n' -> text.append('\n');
                    case 'r' -> text.append('\r');
                    case 't' -> text.append('\t');
                    case 'u' -> {
                        if (position + 4 > source.length()) return fail("Некорректный Unicode escape.");
                        try {
                            text.append((char) Integer.parseInt(source.substring(position, position + 4), 16));
                        } catch (NumberFormatException exception) {
                            return fail("Некорректный Unicode escape.");
                        }
                        position += 4;
                    }
                    default -> { return fail("Неизвестный escape-код."); }
                }
            }
            return fail("Незаконченная строка JSON.");
        }

        private Object parseNumber() throws IOException {
            int start = position;
            if (take('-')) { }
            while (position < source.length() && Character.isDigit(source.charAt(position))) position++;
            if (start == position || (position == start + 1 && source.charAt(start) == '-')) {
                return fail("Некорректное число.");
            }
            try {
                return Long.parseLong(source.substring(start, position));
            } catch (NumberFormatException exception) {
                return fail("Число вне допустимого диапазона.");
            }
        }

        private Object parseLiteral(String literal, Object value) throws IOException {
            if (!source.startsWith(literal, position)) return fail("Некорректное значение JSON.");
            position += literal.length();
            return value;
        }

        private void skipWhitespace() {
            while (position < source.length() && Character.isWhitespace(source.charAt(position))) position++;
        }

        private boolean take(char expected) {
            if (position < source.length() && source.charAt(position) == expected) {
                position++;
                return true;
            }
            return false;
        }

        private void expect(char expected) throws IOException {
            if (!take(expected)) fail("Ожидался символ '" + expected + "'.");
        }

        private <T> T fail(String message) throws IOException {
            throw new IOException(message + " Позиция: " + position + ".");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new LibraryApp().setVisible(true);
            } catch (IOException | RuntimeException exception) {
                JOptionPane.showMessageDialog(null,
                        "Не удалось открыть библиотеку.\n" + exception.getMessage(),
                        "Ошибка запуска", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
